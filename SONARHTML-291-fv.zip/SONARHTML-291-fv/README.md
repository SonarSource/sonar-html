# SONARHTML-291 Functional Validation

This validation uses a single HTML sample with three ARIA roles:

- `link`
- `status`
- `checkbox`

`master` reports all three roles. The review branch runs the same check with `whitelistedRoles=link,status`, so only `checkbox` remains.

Run:

```bash
./run.sh
```

The expected stdout is stored in `expected-output.txt`.
