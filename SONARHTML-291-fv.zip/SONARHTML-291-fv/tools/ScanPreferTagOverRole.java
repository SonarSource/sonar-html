import java.io.File;
import java.lang.reflect.Field;
import java.util.Comparator;
import java.util.List;
import org.sonar.api.rule.RuleKey;
import org.sonar.plugins.html.checks.HtmlIssue;
import org.sonar.plugins.html.checks.TestHelper;
import org.sonar.plugins.html.checks.accessibility.PreferTagOverRoleCheck;

public class ScanPreferTagOverRole {

  /**
   * Scans the provided HTML sample with PreferTagOverRoleCheck.
   * @param args sample path and optional whitelist
   */
  public static void main(String[] args) throws Exception {
    if (args.length < 1 || args.length > 2) {
      throw new IllegalArgumentException("Usage: ScanPreferTagOverRole <sample-file> [whitelistedRoles]");
    }

    var check = new PreferTagOverRoleCheck();
    check.setRuleKey(RuleKey.of("Web", "S6819"));
    if (args.length == 2 && !args[1].isBlank()) {
      try {
        Field field = PreferTagOverRoleCheck.class.getField("whitelistedRoles");
        field.set(check, args[1]);
      } catch (NoSuchFieldException ignored) {
        // master does not expose the configuration yet
      }
    }

    List<HtmlIssue> issues = TestHelper.scan(new File(args[0]), check).getIssues().stream()
      .sorted(
        Comparator.comparing((HtmlIssue issue) -> issue.line() == null ? Integer.MAX_VALUE : issue.line())
          .thenComparing(HtmlIssue::message)
      )
      .toList();

    for (HtmlIssue issue : issues) {
      String rule = issue.ruleKey().toString();
      int separator = rule.indexOf(':');
      if (separator >= 0) {
        rule = rule.substring(separator + 1);
      }
      String line = issue.line() == null ? "?" : issue.line().toString();
      System.out.println("Rule \"" + rule + "\" -> L." + line + ": " + issue.message());
    }
  }
}
