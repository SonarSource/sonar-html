#!/usr/bin/env bash
set -euo pipefail

ROOT="$(CDPATH= cd -- "$(dirname "$0")" && pwd)"
WORK="$ROOT/work"
SAMPLE="$ROOT/sample/prefer-tag-over-role.html"
RUNNER_SRC="$ROOT/tools/ScanPreferTagOverRole.java"
WHITELISTED_ROLES="link,status"

build_repo() {
  local bare_repo="$1"
  local worktree_dir="$2"

  git clone --quiet "$bare_repo" "$worktree_dir"
  (
    cd "$worktree_dir"
    mvn -pl sonar-html-plugin -q -DskipTests test-compile dependency:build-classpath \
      -Dmdep.outputFile=target/test.classpath >/dev/null
  )
}

build_classpath() {
  local repo_dir="$1"
  printf '%s:%s/sonar-html-plugin/target/classes:%s/sonar-html-plugin/target/test-classes' \
    "$(cat "$repo_dir/sonar-html-plugin/target/test.classpath")" \
    "$repo_dir" \
    "$repo_dir"
}

compile_runner() {
  local repo_dir="$1"
  local bin_dir="$2"

  mkdir -p "$bin_dir"
  javac -cp "$(build_classpath "$repo_dir")" -d "$bin_dir" "$RUNNER_SRC"
}

print_results() {
  local banner="$1"
  local repo_dir="$2"
  local whitelist="$3"
  local bin_dir="$4"
  local classpath
  local output

  classpath="$(build_classpath "$repo_dir"):$bin_dir"
  if [[ -n "$whitelist" ]]; then
    output="$(java -cp "$classpath" ScanPreferTagOverRole "$SAMPLE" "$whitelist")"
  else
    output="$(java -cp "$classpath" ScanPreferTagOverRole "$SAMPLE")"
  fi

  printf '%s\n' "$banner"
  if [[ -n "$whitelist" ]]; then
    printf 'Analyzing "prefer-tag-over-role.html" with whitelistedRoles="%s"...\n' "$whitelist"
  else
    printf 'Analyzing "prefer-tag-over-role.html"...\n'
  fi
  printf 'Results:\n'
  if [[ -n "$output" ]]; then
    while IFS= read -r line; do
      printf '    - %s\n' "$line"
    done <<<"$output"
  else
    printf '    (none)\n'
  fi
}

rm -rf "$WORK"
mkdir -p "$WORK/master" "$WORK/branch" "$WORK/bin/master" "$WORK/bin/branch"

build_repo "$ROOT/repos/sonar-html-master.git" "$WORK/master/sonar-html"
build_repo "$ROOT/repos/sonar-html-branch.git" "$WORK/branch/sonar-html"

compile_runner "$WORK/master/sonar-html" "$WORK/bin/master"
compile_runner "$WORK/branch/sonar-html" "$WORK/bin/branch"

print_results "******************* MASTER *******************" "$WORK/master/sonar-html" "" "$WORK/bin/master"
printf '\n'
print_results "****** Branch \"SONARHTML-291-whitelisted-roles\" ******" "$WORK/branch/sonar-html" "$WHITELISTED_ROLES" "$WORK/bin/branch"
